


<?php
    // Dummy data for Employees
    $employees = collect([
        (object) [
            'id' => 1,
            'name' => 'John Doe',
            'avatar' => asset('assets/images/users/avatar-1.jpg'),
            'role' => 'Super Admin',
            'role_badge' => 'bg-primary-subtle text-primary',
            'email' => 'johndoe@company.com',
            'department' => 'IT',
            'status' => 'Active',
            'status_badge' => 'bg-success-subtle text-success',
            'joined_date' => '15 Oct, 2025',
        ],
        (object) [
            'id' => 2,
            'name' => 'Jane Smith',
            'avatar' => asset('assets/images/users/avatar-2.jpg'),
            'role' => 'Moderator',
            'role_badge' => 'bg-info-subtle text-info',
            'email' => 'janesmith@company.com',
            'department' => 'HR',
            'status' => 'Pending',
            'status_badge' => 'bg-warning-subtle text-warning',
            'joined_date' => '20 Nov, 2025',
        ],
        (object) [
            'id' => 3,
            'name' => 'Mike Johnson',
            'avatar' => asset('assets/images/users/avatar-3.jpg'),
            'role' => 'Support Staff',
            'role_badge' => 'bg-success-subtle text-success',
            'email' => 'mikejohnson@company.com',
            'department' => 'Customer Service',
            'status' => 'Active',
            'status_badge' => 'bg-success-subtle text-success',
            'joined_date' => '10 Sep, 2025',
        ],
        (object) [
            'id' => 4,
            'name' => 'Sarah Wilson',
            'avatar' => asset('assets/images/users/avatar-4.jpg'),
            'role' => 'Analyst',
            'role_badge' => 'bg-secondary-subtle text-secondary',
            'email' => 'sarahwilson@company.com',
            'department' => 'Finance',
            'status' => 'Inactive',
            'status_badge' => 'bg-danger-subtle text-danger',
            'joined_date' => '05 Aug, 2025',
        ],
        // Add more dummy employees as needed
    ]);
?>

<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">Employees List</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="">Staff Management</a></li>
                        <li class="breadcrumb-item active">Employees</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Manage Admin Team Members</h4>
                    <div class="flex-shrink-0">
                        <button type="button" class="btn btn-soft-primary btn-sm material-shadow-none" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                            <i class="ri-add-line align-middle"></i> Add New Employee
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive table-card">
                        <table class="table table-borderless table-centered align-middle table-nowrap mb-0">
                            <thead class="text-muted table-light">
                                <tr>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Joined Date</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0 me-2">
                                                    <img src="<?php echo e($employee->avatar); ?>" alt="" class="avatar-xs rounded-circle" />
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="fs-14 mb-0"><?php echo e($employee->name); ?></h6>
                                                    <span class="text-muted fs-12">Admin</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($employee->email); ?></td>
                                        <td><span class="badge <?php echo e($employee->role_badge); ?>"><?php echo e($employee->role); ?></span></td>
                                        <td><?php echo e($employee->department); ?></td>
                                        <td><span class="badge <?php echo e($employee->status_badge); ?>"><?php echo e($employee->status); ?></span></td>
                                        <td><?php echo e($employee->joined_date); ?></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-info">View</a>
                                            <a href="#" class="btn btn-sm btn-warning">Edit</a>
                                            <form action="#" method="POST" style="display: inline;" onsubmit="return confirm('Delete this employee?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <i class="ri-team-line fs-2 text-muted mb-2 d-block"></i>
                                            <p class="text-muted">No employees found.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addEmployeeModalLabel">Add New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="employeeName" class="form-label">Full Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="employeeName" name="name" placeholder="Enter full name" value="<?php echo e(old('name')); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="employeeEmail" class="form-label">Email</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="employeeEmail" name="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="employeeRole" class="form-label">Role</label>
                            <select class="form-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="employeeRole" name="role" required>
                                <option value="">Select Role</option>
                                <option value="super-admin" <?php echo e(old('role') == 'super-admin' ? 'selected' : ''); ?>>Super Admin</option>
                                <option value="moderator" <?php echo e(old('role') == 'moderator' ? 'selected' : ''); ?>>Moderator</option>
                                <option value="support" <?php echo e(old('role') == 'support' ? 'selected' : ''); ?>>Support Staff</option>
                                <option value="analyst" <?php echo e(old('role') == 'analyst' ? 'selected' : ''); ?>>Analyst</option>
                            </select>
                            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="employeeDepartment" class="form-label">Department</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="employeeDepartment" name="department" placeholder="Enter department" value="<?php echo e(old('department')); ?>" required>
                            <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" form="addEmployeeForm" class="btn btn-primary">Add Employee</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/admin/employee.blade.php ENDPATH**/ ?>