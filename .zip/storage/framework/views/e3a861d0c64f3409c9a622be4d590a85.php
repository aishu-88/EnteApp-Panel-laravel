

<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">Verification Requests</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Verification Requests</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Users Awaiting Verification Approval</h5>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>User</th>
                                    <th>Email</th>
                                    <th>Requested Role</th>
                                    <th>ID Proof</th>
                                    <th>Submitted On</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0 me-2">
                                                    <img src="<?php echo e($req->user->avatar ? Storage::url($req->user->avatar) : asset('assets/images/users/avatar-1.jpg')); ?>"
                                                         alt="<?php echo e($req->user->name); ?>"
                                                         class="avatar-xs rounded-circle">
                                                </div>
                                                <div class="flex-grow-1"><?php echo e($req->user->name); ?></div>
                                            </div>
                                        </td>

                                        
                                        <td><?php echo e($req->user->email); ?></td>

                                        
                                        <td><?php echo e(ucfirst($req->requested_role)); ?></td>

                                        
                                        <td>
                                            <?php if($req->document_path): ?>
                                                <a href="<?php echo e(Storage::url($req->document_path)); ?>"
                                                   class="btn btn-sm btn-info"
                                                   target="_blank">
                                                    View Document
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">No File</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td><?php echo e($req->created_at->format('Y-m-d')); ?></td>

                                        
                                        <td>
                                            <?php if($req->status === 'pending'): ?>
                                                <span class="badge bg-warning">Pending</span>
                                            <?php elseif($req->status === 'approved'): ?>
                                                <span class="badge bg-success">Approved</span>
                                            <?php elseif($req->status === 'rejected'): ?>
                                                <span class="badge bg-danger">Rejected</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            
                                            <form action="<?php echo e(route('admin.verification.approve', $req->id)); ?>"
                                                  method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-success me-1"
                                                        onclick="return confirm('Approve this verification request?')">
                                                    Approve
                                                </button>
                                            </form>

                                            
                                            <form action="<?php echo e(route('admin.verification.reject', $req->id)); ?>"
                                                  method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Reject this verification request?')">
                                                    Reject
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No verification requests found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <div class="d-flex justify-content-end mt-3">
                        <?php echo e($requests->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/admin/verification.blade.php ENDPATH**/ ?>