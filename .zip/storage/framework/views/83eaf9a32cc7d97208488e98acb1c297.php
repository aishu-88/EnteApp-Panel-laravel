


<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">All Listings</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Listings</a></li>
                        <li class="breadcrumb-item active">All Active Listings</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="row mb-3">
        <div class="col-12">
            <form method="GET" action="<?php echo e(route('admin.all-listings')); ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="search" placeholder="Search by title, provider, or type..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary">Search</button>
                        <a href="<?php echo e(route('admin.all-listings')); ?>" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">All Active Services and Shop Listings (<?php echo e($listings->total()); ?> total)</h5>
                </div>
                <div class="card-body">
                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-xl-4 col-md-6">
                                <div class="card listing-card">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="flex-shrink-0">
                                                <span class="listing-icon <?php echo e($listing->type === 'service' ? 'service-icon' : 'shop-icon'); ?>">
                                                    <i class="<?php echo e($listing->icon ?? ($listing->type === 'service' ? 'ri-plug-2-line' : 'ri-store-line')); ?>"></i>
                                                </span>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-1"><?php echo e($listing->title); ?></h6>
                                                <p class="text-muted mb-0 small">Listing by <?php echo e($listing->provider_name); ?></p>
                                            </div>
                                            <div class="flex-shrink-0">
                                                <span class="badge bg-success-subtle text-success">Active</span>
                                            </div>
                                        </div>
                                        <p class="text-muted small mb-3"><?php echo e(Str::limit($listing->description, 100)); ?></p>
                                        <div class="d-flex gap-2">
                                            <a href="<?php echo e(route('admin.listings.show', $listing->id)); ?>" class="btn btn-sm btn-primary">View</a>
                                            <a href="<?php echo e(route('admin.listings.edit', $listing->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <form action="<?php echo e(route('admin.listings.deactivate', $listing->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Deactivate this listing?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Deactivate</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <div class="text-center py-5">
                                    <i class="ri-list-unordered fs-1 text-muted mb-3 d-block"></i>
                                    <h5 class="text-muted">No listings found.</h5>
                                    <p class="text-muted"><?php echo e(request('search') ? 'Try adjusting your search.' : 'No active listings yet.'); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if($listings->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($listings->appends(request()->query())->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/admin/all_list.blade.php ENDPATH**/ ?>