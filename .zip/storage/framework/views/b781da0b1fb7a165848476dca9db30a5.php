


<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">Pending Approvals</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.all-listings')); ?>">Listings</a></li>
                        <li class="breadcrumb-item active">Pending Approvals</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="row mb-3">
        <div class="col-12">
            <form method="GET" action="<?php echo e(route('admin.pending-approvals')); ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="search" placeholder="Search by title, provider, or type..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary">Search</button>
                        <a href="<?php echo e(route('admin.pending-approvals')); ?>" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">New or updated listings waiting for admin approval (<?php echo e($listings->total()); ?> total)</h5>
                </div>
                <div class="card-body">
                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-xl-4 col-md-6">
                                <div class="card listing-card">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="flex-shrink-0">
                                                <span class="listing-icon <?php echo e($listing->type === 'service' ? 'service-icon' : 'shop-icon'); ?>">
                                                    <i class="<?php echo e($listing->icon ?? ($listing->type === 'service' ? 'ri-tools-line' : 'ri-building-line')); ?>"></i>
                                                </span>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-1"><?php echo e($listing->title); ?></h6>
                                                <p class="text-muted mb-0 small"><?php echo e($listing->type === 'service' ? 'Service' : 'Shop'); ?> by <?php echo e($listing->provider_name); ?> <?php echo e($listing->updated_at->diffForHumans()); ?></p>
                                            </div>
                                            <div class="flex-shrink-0">
                                                <span class="badge pending-badge">Pending</span>
                                            </div>
                                        </div>
                                        <p class="text-muted small mb-3"><?php echo e(Str::limit($listing->description, 100)); ?></p>
                                        <div class="d-flex gap-1 approval-actions">
                                            <a href="<?php echo e(route('admin.listings.show', $listing->id)); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                            <form action="<?php echo e(route('admin.listings.approve', $listing->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Approve this listing?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                            </form>
                                            <form action="<?php echo e(route('admin.listings.reject', $listing->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Reject this listing?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Reject</button>
                                            </form>
                                            <a href="<?php echo e(route('admin.listings.edit', $listing->id)); ?>" class="btn btn-sm btn-outline-warning">Edit</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <div class="text-center py-5">
                                    <i class="ri-time-line fs-1 text-muted mb-3 d-block"></i>
                                    <h5 class="text-muted">No pending approvals.</h5>
                                    <p class="text-muted"><?php echo e(request('search') ? 'Try adjusting your search.' : 'All listings are approved.'); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if($listings->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($listings->appends(request()->query())->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/admin/pending_approval.blade.php ENDPATH**/ ?>