


<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">Service Providers</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.all-users')); ?>">Users</a></li>
                        <li class="breadcrumb-item active">Service Providers</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="row mb-3">
        <div class="col-12">
            <form method="GET" action="<?php echo e(route('admin.service-providers')); ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="search" placeholder="Search by name, email, or service type..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary">Search</button>
                        <a href="<?php echo e(route('admin.service-providers')); ?>" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Individuals who offer services (electrician, driver, plumber) (<?php echo e(isset($users->total) ? $users->total() : $users->count()); ?> total)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Service Type</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Joined Date</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0 me-2">
                                                    <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->name); ?>" class="avatar-xs rounded-circle" />
                                                </div>
                                                <div class="flex-grow-1"><?php echo e($user->name); ?></div>
                                            </div>
                                        </td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <span class="badge bg-info-subtle text-info"><?php echo e($user->service_type ?? ucfirst(str_replace('_', ' ', $user->user_type))); ?></span>
                                        </td>
                                        <td>
                                            <?php $statusClass = match($user->status ?? 'active') { 'active' => 'bg-success', 'pending' => 'bg-warning', 'blocked' => 'bg-danger', default => 'bg-secondary' }; ?>
                                            <span class="badge <?php echo e($statusClass); ?> text-<?php echo e(Str::before($statusClass, '-')); ?>"><?php echo e(ucfirst($user->status ?? 'active')); ?></span>
                                        </td>
                                        <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                                        <td>
                                            <a href="" class="btn btn-sm btn-primary me-1">
                                                <i class="ri-eye-line"></i> View
                                            </a>
                                            <a href="" class="btn btn-sm btn-warning me-1">
                                                <i class="ri-edit-line"></i> Edit
                                            </a>
                                            <?php if(($user->status ?? 'active') === 'blocked'): ?>
                                                <form action="" method="POST" style="display: inline;" onsubmit="return confirm('Unblock this user?')">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-sm btn-success">
                                                        <i class="ri-unlock-line"></i> Unblock
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <form action="" method="POST" style="display: inline;" onsubmit="return confirm('Block this user?')">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        <i class="ri-lock-line"></i> Block
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <div class="text-muted">
                                                <i class="ri-handshake-line fs-2 mb-2 d-block"></i>
                                                No service providers found. <?php echo e(request('search') ? 'Try adjusting your search.' : 'Start by approving providers.'); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if(method_exists($users, 'links')): ?>
                        <div class="d-flex justify-content-end mt-3">
                            <?php echo e($users->appends(request()->query())->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/admin/service_provider.blade.php ENDPATH**/ ?>