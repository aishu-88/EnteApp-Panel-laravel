

<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">All Users</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Users</a></li>
                        <li class="breadcrumb-item active">All Users</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">See Every User Registered in the App</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">User Type</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Registered Date</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0 me-2">
                                                    <img src="<?php echo e($user->avatar ? Storage::url($user->avatar) : asset('assets/images/users/avatar-1.jpg')); ?>" alt="<?php echo e($user->name); ?>" class="avatar-xs rounded-circle" />
                                                </div>
                                                <div class="flex-grow-1"><?php echo e($user->name); ?></div>
                                            </div>
                                        </td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->user_type ?? 'Regular User'); ?></td>
                                        <td>
                                            <?php if($user->status === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php elseif($user->status === 'pending'): ?>
                                                <span class="badge bg-warning">Pending</span>
                                            <?php elseif($user->status === 'blocked'): ?>
                                                <span class="badge bg-danger">Blocked</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                                        <td>
                                            <a href="" class="btn btn-sm btn-primary me-1">View</a>
                                            <a href="" class="btn btn-sm btn-warning me-1">Edit</a>
                                            <?php if($user->status === 'blocked'): ?>
                                                <form action="<?php echo e(route('admin.users.unblock', $user->id)); ?>" method="POST" style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Unblock this user?')">Unblock</button>
                                                </form>
                                            <?php else: ?>
                                                <form action="" method="POST" style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Block this user?')">Block</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No users found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-end mt-3">
                        <?php echo e($users->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/admin/all_users.blade.php ENDPATH**/ ?>