

<?php $__env->startSection('title', 'My Vendors'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">My Vendors</h4>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('provider.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Vendor List</li>
            </ol>
        </div>
    </div>
</div>


<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="">
            <div class="row g-3">

                <div class="col-md-3">
                    <input type="text" name="name" class="form-control"
                        placeholder="Search by Name" value="<?php echo e(request('name')); ?>">
                </div>

                <div class="col-md-2">
                    <input type="text" name="category" class="form-control"
                        placeholder="Category" value="<?php echo e(request('category')); ?>">
                </div>

                <div class="col-md-2">
                    <input type="text" name="ward" class="form-control"
                        placeholder="Ward / Area" value="<?php echo e(request('ward')); ?>">
                </div>

                <div class="col-md-2">
                    <select name="plan_id" class="form-select">
                        <option value="">Plan Type</option>
                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('plan_id') == $i ? 'selected' : ''); ?>>
                                Plan <?php echo e($i); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <button class="btn btn-primary me-1">
                        <i class="ri-search-line"></i> Search
                    </button>
                    <a href="" class="btn btn-light">
                        Reset
                    </a>
                </div>

            </div>
        </form>
    </div>
</div>


<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Shop</th>
                        <th>Category</th>
                        <th>Contact</th>
                        <th>Location</th>
                        <th>Plan</th>
                        <th>Status</th>
                        <th>Verification</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong><?php echo e($vendor->shop_name); ?></strong><br>
                                <small class="text-muted"><?php echo e($vendor->owner_name); ?></small>
                            </td>

                            <td><?php echo e($vendor->category); ?></td>

                            <td>
                                <?php echo e($vendor->mobile); ?><br>
                                <small><?php echo e($vendor->whatsapp); ?></small>
                            </td>

                            <td><?php echo e($vendor->address); ?></td>

                            <td>
                                <span class="badge bg-info">Plan <?php echo e($vendor->plan_id); ?></span>
                            </td>

                            <td>
                                <?php if($vendor->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Disabled</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <span class="badge <?php echo e($vendor->verification_status == 'Verified' ? 'bg-success' : 'bg-warning'); ?>">
                                    <?php echo e($vendor->verification_status); ?>

                                </span>
                            </td>

                            <td>
                                <a href="<?php echo e(route('provider.vendors.edit', $vendor->id)); ?>"
                                   class="btn btn-sm btn-primary">
                                    Edit
                                </a>

                                <form action="<?php echo e(route('provider.vendors.toggle', $vendor->id)); ?>"
                                      method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-sm btn-warning">
                                        <?php echo e($vendor->is_active ? 'Disable' : 'Enable'); ?>

                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">
                                No vendors found
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($vendors->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.provider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\myProject\resources\views/provider/vendor_list.blade.php ENDPATH**/ ?>